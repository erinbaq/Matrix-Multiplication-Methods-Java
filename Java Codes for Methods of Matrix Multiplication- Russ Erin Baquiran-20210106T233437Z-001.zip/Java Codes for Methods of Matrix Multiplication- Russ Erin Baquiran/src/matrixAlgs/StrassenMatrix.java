package matrixAlgs;

import java.util.Random;

public class StrassenMatrix {
	public static void main(String[] args)
	{
		final int times = 20;				 //how many times ran through
		int n;
		
		long timeS, timeE;			//start, end
        long totalTimeS = 0;		//Strassens

        int[][] A, B;
        
        for (int i = 1; i <9; i++) {			// until 256x256 matrix
            n = (int) Math.pow(2, i);
			for(int h=0;h<100;h++)				// 100 sets of input
			{
            A = generateMat(n);
            B = generateMat(n);
            for (int j = 0; j < times; j++) 
            {	// times run
				timeS = System.nanoTime();
				strassenMatD(A, B, A.length);
				timeE = System.nanoTime();
				totalTimeS += timeE - timeS;
            }
			totalTimeS+= totalTimeS / times;      //get avg of ALL
			}
          System.out.println("For "+n+"x"+n+ ": Strassen's Matrix Multiplication time: "
        		  			+ totalTimeS + " nanoseconds.");
        	}
        }
        
    	public static int[][] generateMat(int n) 
    	{
 	       Random r = new Random();
 	       int[][] matrix = new int[n][n];

 	       for (int i = 0; i < n; i++) {				//create random matrix for nxn
 	           for (int j = 0; j < n; j++) {
 	               matrix[i][j] = r.nextInt(100);
 	           }
 	       }
 	       return matrix;
 	   }
        
    	private static int[][] addMat(int[][] A, int[][] B, int n) 
    	{

    		int[][] C = new int[n][n];

    		for (int i = 0; i < n; i++) {
    			for (int j = 0; j < n; j++) {						//add matrices
    				C[i][j] = A[i][j] + B[i][j];
    			}
    		}
    		return C;
    	}	
    	
    	private static int[][] minusMat(int[][] A, int[][] B, int n) 
    	{

    		int[][] C = new int[n][n];

    		for (int i = 0; i < n; i++) {
    			for (int j = 0; j < n; j++) {						//subtract matrices
    				C[i][j] = A[i][j] - B[i][j];
    			}
    		}
    		return C;
    	}	
    	
    	private static void constMat(int[][] inMat,	int[][] newMatrix, int a, int b) 
    	{
    		int y = b;

    		for (int i = 0; i < inMat.length; i++) {
    			for (int j = 0; j < inMat.length; j++) {			//construct matrix
    				newMatrix[a][y++] = inMat[i][j];
    			}
    			y = b;
    			a++;
    		}
    	}
    	
    	private static void deconstMat(int[][] inMat, int[][] newM, int a, int b) 
    	{
    		int y = b;
    		for (int i = 0; i < newM.length; i++) 
    		{
    			for (int j = 0; j < newM.length; j++) 			//deconstruct matrix
    			{
    				newM[i][j] = inMat[a][y++];
    			}
    			y = b;
    			a++;
    		}
    	}
	
	public static int[][] strassenMatD(int[][] A, int[][] B, int n) 
	{
		int[][] C = new int[n][n];
		strassenMat(A, B, C, n);						//"driver" for strassenMat
		return C;
	}
	
	public static void strassenMat(int[][] A, int[][] B, int[][] C, int n) 
	{
		if (n == 2) 
		{
			C[0][0] = (A[0][0] * B[0][0]) + (A[0][1] * B[1][0]);		//prediction: should be slowest because using "driver"
			C[0][1] = (A[0][0] * B[0][1]) + (A[0][1] * B[1][1]);
			C[1][0] = (A[1][0] * B[0][0]) + (A[1][1] * B[1][0]);
			C[1][1] = (A[1][0] * B[0][1]) + (A[1][1] * B[1][1]);
		} else 
		{
			int[][] A11 = new int[n/2][n/2];
			int[][] A12 = new int[n/2][n/2];
			int[][] A21 = new int[n/2][n/2];
			int[][] A22 = new int[n/2][n/2];
			int[][] B11 = new int[n/2][n/2];
			int[][] B12 = new int[n/2][n/2];
			int[][] B21 = new int[n/2][n/2];
			int[][] B22 = new int[n/2][n/2];
			int[][] P = new int[n/2][n/2];
			int[][] Q = new int[n/2][n/2];
			int[][] R = new int[n/2][n/2];
			int[][] S = new int[n/2][n/2];
			int[][] T = new int[n/2][n/2];
			int[][] U = new int[n/2][n/2];
			int[][] V = new int[n/2][n/2];
			deconstMat(A, A11, 0, 0);
			deconstMat(A, A12, 0, n/2);
			deconstMat(A, A21, n/2, 0);
			deconstMat(A, A22, n/2, n/2);
			deconstMat(B, B11, 0, 0);
			deconstMat(B, B12, 0, n/2);
			deconstMat(B, B21, n/2, 0);
			deconstMat(B, B22, n/2, n/2);

			strassenMat(addMat(A11, A22, n/2),addMat(B11, B22, n/2), P, n/2);
			strassenMat(addMat(A21, A22, n/2), B11, Q, n/2);
			strassenMat(A11, minusMat(B12, B22, n/2), R, n/2);
			strassenMat(A22, minusMat(B21, B11, n/2), S, n/2);
			strassenMat(addMat(A11, A12, n/2), B22, T, n/2);
			strassenMat(minusMat(A21, A11, n/2),addMat(B11, B12, n/2), U, n/2);
			strassenMat(minusMat(A12, A22, n/2),addMat(B21, B22, n/2), V, n/2);

			int[][] C11 = addMat(minusMat(addMat(P, S, P.length), T, T.length), V, V.length);
			int[][] C12 = addMat(R, T, R.length);
			int[][] C21 = addMat(Q, S, Q.length);
			int[][] C22 = addMat(minusMat(addMat(P, R, P.length), Q, Q.length), U, U.length);

			constMat(C11, C, 0, 0);
			constMat(C12, C, 0, n/2);
			constMat(C21, C, n/2, 0);
			constMat(C22, C, n/2, n/2);
		}
	}	
		    
}
