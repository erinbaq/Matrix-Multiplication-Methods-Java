package matrixAlgs;
import java.util.Random;
import java.util.Scanner;

public class ClassicalMatrix {

	public static void main(String[] args)
	{
		final int times = 20;
		int n;
		long timeS, timeE;
		long totalTimeC = 0;
        int[][] A, B;
        
        for (int i = 1; i <9; i++) {
            n = (int) Math.pow(2, i);
            
			for(int h=0;h<100;h++)
			{
            A = generateMat(n);
            B = generateMat(n);
            for (int j = 0; j < times; j++) {
                timeS = System.nanoTime();
                classic(A, B, A.length);
                timeE = System.nanoTime();
                totalTimeC += timeE - timeS;
                
            }
            totalTimeC+= totalTimeC / times;
			}
          System.out.println("For "+n+"x"+n+ ": Classic Matrix Multiplication time: "
        		  			+ totalTimeC + " nanoseconds.");
        

        }
	}
	
	
	public static int[][] generateMat(int n) {
	       Random r = new Random();
	       int[][] matrix = new int[n][n];

	       for (int i = 0; i < n; i++) {
	           for (int j = 0; j < n; j++) {
	               matrix[i][j] = r.nextInt(100);
	           }
	       }
	       return matrix;
	   }

	public static int[][] classic(int[][] A, int[][] B, int n) {
	       int[][] C = new int[n][n];

	       for (int i = 0; i < n; i++) {
	           for (int j = 0; j < n; j++) {
	               C[i][j] = 0;
	           }
	       }

	       for (int i = 0; i < n; i++) {
	           for (int j = 0; j < n; j++) {
	               for (int k = 0; k < n; k++) {
	                   C[i][j] += A[i][k] * B[k][j];
	               }
	           }
	       }
	       return C;
	   }


}



